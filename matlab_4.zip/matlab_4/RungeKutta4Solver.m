classdef RungeKutta4Solver < DifferentialEquationSolver
    % RUNGEKUTTA4SOLVER Concrete implementation of RK4 method
    
    methods
        function obj = RungeKutta4Solver(odeFun, tSpan, h, y0, analyticalFun, tolerance, maxIterations)
            obj = obj@DifferentialEquationSolver('Runge-Kutta 4', odeFun, tSpan, h, y0, analyticalFun, tolerance, maxIterations);
        end
        
        function result = solve(obj)
            % Implement RK4 method recursively
            tic;
            obj.validateParameters();
            
            % Initialize arrays
            t_array = zeros(1, length(obj.timeVector));
            y_array = zeros(1, length(obj.timeVector));
            t_array(1) = obj.timeVector(1);
            y_array(1) = obj.initialCondition;
            
            % Solve using iterative approach (more reliable than recursive for ODEs)
            for step = 1:length(obj.timeVector)-1
                t_current = t_array(step);
                y_current = y_array(step);
                
                % RK4 calculations
                k1 = obj.stepSize * obj.odeFunction(t_current, y_current);
                k2 = obj.stepSize * obj.odeFunction(t_current + obj.stepSize/2, y_current + k1/2);
                k3 = obj.stepSize * obj.odeFunction(t_current + obj.stepSize/2, y_current + k2/2);
                k4 = obj.stepSize * obj.odeFunction(t_current + obj.stepSize, y_current + k3);
                
                y_next = y_current + (k1 + 2*k2 + 2*k3 + k4) / 6;
                
                % Store results
                t_array(step + 1) = obj.timeVector(step + 1);
                y_array(step + 1) = y_next;
                
                if mod(step, 10) == 0
                    fprintf('  Step %d: t = %.2f, y = %.6f\n', step, t_array(step + 1), y_next);
                end
            end
            
            obj.solution = y_array;
            obj.timeVector = t_array;
            obj.calculateErrors();
            obj.computationTime = toc;
            
            result = struct('time', obj.timeVector, 'solution', obj.solution, ...
                          'max_error', obj.maxError, 'time_elapsed', obj.computationTime);
        end
    end
end