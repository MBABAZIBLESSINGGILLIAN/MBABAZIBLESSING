classdef NumericalMethodsGUI < handle
    % NUMERICALMETHODSGUI Main GUI application for numerical methods
    % Provides a user-friendly interface for root finding and ODE solving
    
    properties
        % Main window components
        fig
        tabGroup
        
        % Root Finding Tab
        rootTab
        rootMethodDropdown
        rootFunctionEdit
        rootDerivativeEdit
        rootInitialEdit
        rootSecondLabel
        rootSecondEdit
        rootLowerLabel
        rootLowerEdit
        rootUpperLabel
        rootUpperEdit
        rootToleranceEdit
        rootMaxIterEdit
        rootSolveButton
        rootResultsText
        rootPlotPanel
        
        % ODE Solving Tab
        odeTab
        odeMethodDropdown
        odeFunctionEdit
        odeInitialEdit
        odeTStartEdit
        odeTEndEdit
        odeStepSizeEdit
        odeAnalyticalEdit
        odeToleranceEdit
        odeMaxIterEdit
        odeSolveButton
        odeResultsText
        odePlotPanel
        
        % Results storage
        currentSolver
        currentResults
    end
    
    methods
        function obj = NumericalMethodsGUI()
            % Constructor - create the main GUI
            obj.createMainWindow();
        end
        
        function createMainWindow(obj)
            % Create main application window
            obj.fig = uifigure('Name', 'Advanced Numerical Methods Solver', ...
                              'Position', [100 100 1200 800], ...
                              'Color', [0.95 0.95 0.95]);
            
            % Create tab group
            obj.tabGroup = uitabgroup(obj.fig, 'Position', [20 20 1160 760]);
            
            % Create tabs
            obj.createRootFindingTab();
            obj.createODESolvingTab();
        end
        
        function createRootFindingTab(obj)
            % Create Root Finding tab
            obj.rootTab = uitab(obj.tabGroup, 'Title', 'Root Finding Methods');
            
            % Title
            uilabel(obj.rootTab, 'Position', [20 720 300 30], ...
                   'Text', 'Root Finding Methods', 'FontSize', 18, ...
                   'FontWeight', 'bold', 'FontColor', [0 0.4 0.8]);
            
            % Method selection
            uilabel(obj.rootTab, 'Position', [20 680 120 20], ...
                   'Text', 'Method:', 'FontWeight', 'bold');
            obj.rootMethodDropdown = uidropdown(obj.rootTab, ...
                'Position', [150 680 200 25], ...
                'Items', {'Newton-Raphson', 'Bisection', 'Secant'}, ...
                'Value', 'Newton-Raphson', ...
                'ValueChangedFcn', @(src,event) obj.updateRootInputs());
            
            % Function input
            uilabel(obj.rootTab, 'Position', [20 640 120 20], ...
                   'Text', 'f(x):', 'FontWeight', 'bold');
            obj.rootFunctionEdit = uieditfield(obj.rootTab, 'text', ...
                'Position', [150 640 300 25], ...
                'Value', '(8/3)*pi*x - 2000./(x.^2)', ...
                'Tooltip', 'Enter function f(x) as MATLAB expression');
            
            % Derivative input (initially visible for Newton-Raphson)
            uilabel(obj.rootTab, 'Position', [20 600 120 20], ...
                   'Text', 'f''(x):', 'FontWeight', 'bold');
            obj.rootDerivativeEdit = uieditfield(obj.rootTab, 'text', ...
                'Position', [150 600 300 25], ...
                'Value', '(8/3)*pi + 4000./(x.^3)', ...
                'Tooltip', 'Enter derivative df/dx as MATLAB expression');
            
            % Initial guess input
            uilabel(obj.rootTab, 'Position', [20 560 120 20], ...
                   'Text', 'Initial Guess (x0):', 'FontWeight', 'bold');
            obj.rootInitialEdit = uieditfield(obj.rootTab, 'numeric', ...
                'Position', [150 560 100 25], 'Value', 10);
            
            % Second guess input (initially hidden for Secant)
            obj.rootSecondLabel = uilabel(obj.rootTab, 'Position', [20 520 120 20], ...
                   'Text', 'Second Guess (x1):', 'FontWeight', 'bold', ...
                   'Visible', 'off');
            obj.rootSecondEdit = uieditfield(obj.rootTab, 'numeric', ...
                'Position', [150 520 100 25], 'Value', 15, 'Visible', 'off');
            
            % Bounds inputs (initially hidden for Bisection)
            obj.rootLowerLabel = uilabel(obj.rootTab, 'Position', [20 520 120 20], ...
                   'Text', 'Lower Bound (a):', 'FontWeight', 'bold', ...
                   'Visible', 'off');
            obj.rootLowerEdit = uieditfield(obj.rootTab, 'numeric', ...
                'Position', [150 520 100 25], 'Value', 5, 'Visible', 'off');
            
            obj.rootUpperLabel = uilabel(obj.rootTab, 'Position', [270 520 120 20], ...
                   'Text', 'Upper Bound (b):', 'FontWeight', 'bold', ...
                   'Visible', 'off');
            obj.rootUpperEdit = uieditfield(obj.rootTab, 'numeric', ...
                'Position', [380 520 100 25], 'Value', 15, 'Visible', 'off');
            
            % Parameters
            uilabel(obj.rootTab, 'Position', [20 460 120 20], ...
                   'Text', 'Tolerance:', 'FontWeight', 'bold');
            obj.rootToleranceEdit = uieditfield(obj.rootTab, 'numeric', ...
                'Position', [150 460 100 25], 'Value', 1e-8);
            
            uilabel(obj.rootTab, 'Position', [20 420 120 20], ...
                   'Text', 'Max Iterations:', 'FontWeight', 'bold');
            obj.rootMaxIterEdit = uieditfield(obj.rootTab, 'numeric', ...
                'Position', [150 420 100 25], 'Value', 100);
            
            % Solve button
            obj.rootSolveButton = uibutton(obj.rootTab, 'push', ...
                'Position', [20 360 120 40], ...
                'Text', 'Solve', ...
                'ButtonPushedFcn', @(src,event) obj.solveRootFinding(), ...
                'BackgroundColor', [0 0.6 0], 'FontColor', 'white', ...
                'FontWeight', 'bold');
            
            % Results display
            uilabel(obj.rootTab, 'Position', [20 320 120 20], ...
                   'Text', 'Results:', 'FontWeight', 'bold');
            obj.rootResultsText = uitextarea(obj.rootTab, ...
                'Position', [20 100 500 210], ...
                'FontName', 'Courier New', 'FontSize', 10);
            
            % Plot panel
            obj.rootPlotPanel = uipanel(obj.rootTab, ...
                'Position', [540 100 600 650], ...
                'Title', 'Results Visualization', ...
                'BackgroundColor', 'white');
            
            % Initialize inputs
            obj.updateRootInputs();
        end
        
        function createODESolvingTab(obj)
            % Create ODE Solving tab
            obj.odeTab = uitab(obj.tabGroup, 'Title', 'ODE Solving Methods');
            
            % Title
            uilabel(obj.odeTab, 'Position', [20 720 300 30], ...
                   'Text', 'ODE Solving Methods', 'FontSize', 18, ...
                   'FontWeight', 'bold', 'FontColor', [0.8 0.4 0]);
            
            % Method selection
            uilabel(obj.odeTab, 'Position', [20 680 120 20], ...
                   'Text', 'Method:', 'FontWeight', 'bold');
            obj.odeMethodDropdown = uidropdown(obj.odeTab, ...
                'Position', [150 680 200 25], ...
                'Items', {'Runge-Kutta 4', 'Runge-Kutta 2', 'Euler'}, ...
                'Value', 'Runge-Kutta 4');
            
            % ODE function input
            uilabel(obj.odeTab, 'Position', [20 640 120 20], ...
                   'Text', 'dy/dt = f(t,y):', 'FontWeight', 'bold');
            obj.odeFunctionEdit = uieditfield(obj.odeTab, 'text', ...
                'Position', [150 640 300 25], ...
                'Value', '-0.5*y', ...
                'Tooltip', 'Enter ODE function f(t,y) as MATLAB expression');
            
            % Initial condition
            uilabel(obj.odeTab, 'Position', [20 600 120 20], ...
                   'Text', 'Initial y(0):', 'FontWeight', 'bold');
            obj.odeInitialEdit = uieditfield(obj.odeTab, 'numeric', ...
                'Position', [150 600 100 25], 'Value', 100);
            
            % Time range
            uilabel(obj.odeTab, 'Position', [20 560 120 20], ...
                   'Text', 'Time Range [t0, tf]:', 'FontWeight', 'bold');
            obj.odeTStartEdit = uieditfield(obj.odeTab, 'numeric', ...
                'Position', [150 560 80 25], 'Value', 0);
            uilabel(obj.odeTab, 'Position', [235 560 20 20], ...
                   'Text', 'to', 'HorizontalAlignment', 'center');
            obj.odeTEndEdit = uieditfield(obj.odeTab, 'numeric', ...
                'Position', [260 560 80 25], 'Value', 10);
            
            % Step size
            uilabel(obj.odeTab, 'Position', [20 520 120 20], ...
                   'Text', 'Step Size (h):', 'FontWeight', 'bold');
            obj.odeStepSizeEdit = uieditfield(obj.odeTab, 'numeric', ...
                'Position', [150 520 100 25], 'Value', 0.1);
            
            % Analytical solution (optional)
            uilabel(obj.odeTab, 'Position', [20 480 120 20], ...
                   'Text', 'Analytical Solution:', 'FontWeight', 'bold');
            obj.odeAnalyticalEdit = uieditfield(obj.odeTab, 'text', ...
                'Position', [150 480 300 25], ...
                'Value', '100 * exp(-0.5*t)', ...
                'Tooltip', 'Enter analytical solution y(t) as MATLAB expression (optional)');
            
            % Parameters
            uilabel(obj.odeTab, 'Position', [20 440 120 20], ...
                   'Text', 'Tolerance:', 'FontWeight', 'bold');
            obj.odeToleranceEdit = uieditfield(obj.odeTab, 'numeric', ...
                'Position', [150 440 100 25], 'Value', 1e-6);
            
            uilabel(obj.odeTab, 'Position', [20 400 120 20], ...
                   'Text', 'Max Iterations:', 'FontWeight', 'bold');
            obj.odeMaxIterEdit = uieditfield(obj.odeTab, 'numeric', ...
                'Position', [150 400 100 25], 'Value', 1000);
            
            % Solve button
            obj.odeSolveButton = uibutton(obj.odeTab, 'push', ...
                'Position', [20 340 120 40], ...
                'Text', 'Solve ODE', ...
                'ButtonPushedFcn', @(src,event) obj.solveODE(), ...
                'BackgroundColor', [0 0.6 0], 'FontColor', 'white', ...
                'FontWeight', 'bold');
            
            % Results display
            uilabel(obj.odeTab, 'Position', [20 300 120 20], ...
                   'Text', 'Results:', 'FontWeight', 'bold');
            obj.odeResultsText = uitextarea(obj.odeTab, ...
                'Position', [20 100 500 190], ...
                'FontName', 'Courier New', 'FontSize', 10);
            
            % Plot panel
            obj.odePlotPanel = uipanel(obj.odeTab, ...
                'Position', [540 100 600 650], ...
                'Title', 'Solution Visualization', ...
                'BackgroundColor', 'white');
        end
        
        function updateRootInputs(obj)
            % Update visible inputs based on selected root finding method
            method = obj.rootMethodDropdown.Value;
            
            % Reset all visibility
            obj.rootDerivativeEdit.Visible = 'on';
            obj.rootSecondLabel.Visible = 'off';
            obj.rootSecondEdit.Visible = 'off';
            obj.rootLowerLabel.Visible = 'off';
            obj.rootLowerEdit.Visible = 'off';
            obj.rootUpperLabel.Visible = 'off';
            obj.rootUpperEdit.Visible = 'off';
            
            switch method
                case 'Newton-Raphson'
                    obj.rootDerivativeEdit.Visible = 'on';
                    
                case 'Bisection'
                    obj.rootDerivativeEdit.Visible = 'off';
                    obj.rootLowerLabel.Visible = 'on';
                    obj.rootLowerEdit.Visible = 'on';
                    obj.rootUpperLabel.Visible = 'on';
                    obj.rootUpperEdit.Visible = 'on';
                    
                case 'Secant'
                    obj.rootDerivativeEdit.Visible = 'off';
                    obj.rootSecondLabel.Visible = 'on';
                    obj.rootSecondEdit.Visible = 'on';
            end
        end
        
        function solveRootFinding(obj)
            % Solve root finding problem based on user inputs
            try
                % Get function handle
                f_str = obj.rootFunctionEdit.Value;
                f = str2func(['@(x) ' f_str]);
                
                % Get parameters
                tolerance = obj.rootToleranceEdit.Value;
                maxIter = obj.rootMaxIterEdit.Value;
                method = obj.rootMethodDropdown.Value;
                
                % Create appropriate solver
                switch method
                    case 'Newton-Raphson'
                        df_str = obj.rootDerivativeEdit.Value;
                        df = str2func(['@(x) ' df_str]);
                        x0 = obj.rootInitialEdit.Value;
                        solver = NewtonRaphsonSolver(f, df, x0, tolerance, maxIter);
                        
                    case 'Bisection'
                        a = obj.rootLowerEdit.Value;
                        b = obj.rootUpperEdit.Value;
                        solver = BisectionSolver(f, a, b, tolerance, maxIter);
                        
                    case 'Secant'
                        x0 = obj.rootInitialEdit.Value;
                        x1 = obj.rootSecondEdit.Value;
                        solver = SecantSolver(f, x0, x1, tolerance, maxIter);
                end
                
                % Solve and display results
                result = solver.solve();
                obj.currentSolver = solver;
                obj.currentResults = result;
                
                % Update results display
                obj.displayRootResults(solver, result);
                
                % Create plots
                obj.plotRootResults(solver, result);
                
            catch ME
                errMsg = sprintf('Error: %s\n\nPlease check your inputs and try again.', ME.message);
                uialert(obj.fig, errMsg, 'Solution Error');
            end
        end
        
        function solveODE(obj)
            % Solve ODE problem based on user inputs
            try
                % Get function handle
                ode_str = obj.odeFunctionEdit.Value;
                ode_fun = str2func(['@(t,y) ' ode_str]);
                
                % Get parameters
                y0 = obj.odeInitialEdit.Value;
                t0 = obj.odeTStartEdit.Value;
                tf = obj.odeTEndEdit.Value;
                h = obj.odeStepSizeEdit.Value;
                tolerance = obj.odeToleranceEdit.Value;
                maxIter = obj.odeMaxIterEdit.Value;
                method = obj.odeMethodDropdown.Value;
                
                % Get analytical solution if provided
                analytical_str = obj.odeAnalyticalEdit.Value;
                if ~isempty(analytical_str)
                    analytical_fun = str2func(['@(t) ' analytical_str]);
                else
                    analytical_fun = [];
                end
                
                % Create appropriate solver
                switch method
                    case 'Runge-Kutta 4'
                        solver = RungeKutta4Solver(ode_fun, [t0, tf], h, y0, analytical_fun, tolerance, maxIter);
                    case 'Runge-Kutta 2'
                        solver = RungeKutta2Solver(ode_fun, [t0, tf], h, y0, analytical_fun, tolerance, maxIter);
                    case 'Euler'
                        solver = EulerSolver(ode_fun, [t0, tf], h, y0, analytical_fun, tolerance, maxIter);
                end
                
                % Solve and display results
                result = solver.solve();
                obj.currentSolver = solver;
                obj.currentResults = result;
                
                % Update results display
                obj.displayODEResults(solver, result);
                
                % Create plots
                obj.plotODEResults(solver, result);
                
            catch ME
                errMsg = sprintf('Error: %s\n\nPlease check your inputs and try again.', ME.message);
                uialert(obj.fig, errMsg, 'Solution Error');
            end
        end
        
        function displayRootResults(obj, solver, result)
            % Display root finding results in text area
            resultsText = sprintf('=== %s RESULTS ===\n\n', upper(solver.name));
            resultsText = [resultsText sprintf('Method: %s\n', solver.name)];
            resultsText = [resultsText sprintf('Root: %.8f\n', result.root)];
            resultsText = [resultsText sprintf('f(root): %.2e\n', solver.problemFunction(result.root))];
            resultsText = [resultsText sprintf('Iterations: %d\n', result.iterations)];
            resultsText = [resultsText sprintf('Computation Time: %.6f seconds\n', result.time)];
            resultsText = [resultsText sprintf('Converged: %s\n', string(result.converged))];
            
            if result.converged
                resultsText = [resultsText sprintf('Solution converged within tolerance\n')];
            else
                resultsText = [resultsText sprintf('Solution did not converge\n')];
            end
            
            obj.rootResultsText.Value = resultsText;
        end
        
        function displayODEResults(obj, solver, ~)
            % Display ODE solving results in text area
            resultsText = sprintf('=== %s RESULTS ===\n\n', upper(solver.name));
            resultsText = [resultsText sprintf('Method: %s\n', solver.name)];
            resultsText = [resultsText sprintf('Step Size: %.4f\n', solver.stepSize)];
            resultsText = [resultsText sprintf('Time Steps: %d\n', length(solver.timeVector))];
            resultsText = [resultsText sprintf('Computation Time: %.6f seconds\n', solver.computationTime)];
            
            if ~isempty(solver.maxError)
                resultsText = [resultsText sprintf('Maximum Error: %.2e\n', solver.maxError)];
                resultsText = [resultsText sprintf('Mean Error: %.2e\n', solver.meanError)];
            end
            
            resultsText = [resultsText sprintf('Final Value: y(%.2f) = %.6f\n', ...
                solver.timeVector(end), solver.solution(end))];
            
            obj.odeResultsText.Value = resultsText;
        end
        
        function plotRootResults(obj, solver, result)
            % Create plots for root finding results
            cla(obj.rootPlotPanel);
            axes('Parent', obj.rootPlotPanel);
            
            % Create subplots
            subplot(2,2,1);
            
            % Plot function and root
            x_min = min([solver.history]) - 1;
            x_max = max([solver.history]) + 1;
            x_plot = linspace(x_min, x_max, 1000);
            y_plot = solver.problemFunction(x_plot);
            
            plot(x_plot, y_plot, 'b-', 'LineWidth', 2);
            hold on;
            plot(result.root, solver.problemFunction(result.root), 'ro', ...
                'MarkerSize', 10, 'MarkerFaceColor', 'red');
            yline(0, 'k--', 'LineWidth', 1);
            xlabel('x');
            ylabel('f(x)');
            title('Function and Root');
            grid on;
            legend('f(x)', 'Root', 'Location', 'best');
            
            subplot(2,2,2);
            % Plot convergence history
            plot(1:length(solver.history), solver.history, 'o-', ...
                'LineWidth', 2, 'MarkerSize', 4);
            xlabel('Iteration');
            ylabel('Solution Value');
            title('Convergence History');
            grid on;
            
            subplot(2,2,3);
            % Plot error convergence
            semilogy(1:length(solver.errorHistory), abs(solver.errorHistory), 's-', ...
                'LineWidth', 2, 'MarkerSize', 4);
            xlabel('Iteration');
            ylabel('Absolute Error');
            title('Error Convergence (log scale)');
            grid on;
            
            subplot(2,2,4);
            % Plot function value at iterations
            f_history = arrayfun(solver.problemFunction, solver.history);
            semilogy(1:length(f_history), abs(f_history), '^-', ...
                'LineWidth', 2, 'MarkerSize', 4);
            xlabel('Iteration');
            ylabel('|f(x)|');
            title('Function Value Convergence');
            grid on;
        end
        
        function plotODEResults(obj, solver, ~)
            % Create plots for ODE results
            cla(obj.odePlotPanel);
            axes('Parent', obj.odePlotPanel);
            
            subplot(2,2,1);
            % Plot numerical solution
            plot(solver.timeVector, solver.solution, 'b-o', ...
                'LineWidth', 2, 'MarkerSize', 3);
            hold on;
            
            % Plot analytical solution if available
            if ~isempty(solver.analyticalSolution)
                t_fine = linspace(solver.timeVector(1), solver.timeVector(end), 1000);
                y_analytical = solver.analyticalSolution(t_fine);
                plot(t_fine, y_analytical, 'r--', 'LineWidth', 2);
                legend('Numerical', 'Analytical', 'Location', 'best');
            else
                legend('Numerical Solution', 'Location', 'best');
            end
            
            xlabel('Time');
            ylabel('y(t)');
            title('ODE Solution');
            grid on;
            
            subplot(2,2,2);
            % Plot error if analytical solution available
            if ~isempty(solver.analyticalSolution)
                errors = abs(solver.solution - solver.analyticalSolution(solver.timeVector));
                plot(solver.timeVector, errors, 'r-s', ...
                    'LineWidth', 2, 'MarkerSize', 3);
                xlabel('Time');
                ylabel('Absolute Error');
                title('Error Analysis');
                grid on;
            else
                text(0.5, 0.5, 'No analytical solution provided for error analysis', ...
                    'HorizontalAlignment', 'center', 'Units', 'normalized');
                title('Error Analysis (No Analytical Solution)');
            end
            
            subplot(2,2,3);
            % Plot phase portrait (dy/dt vs y)
            if length(solver.solution) > 1
                dy_dt = diff(solver.solution) ./ diff(solver.timeVector);
                plot(solver.solution(1:end-1), dy_dt, 'g-', 'LineWidth', 2);
                xlabel('y');
                ylabel('dy/dt');
                title('Phase Portrait');
                grid on;
            end
            
            subplot(2,2,4);
            % Plot computational efficiency
            bar(1, solver.computationTime, 'FaceColor', [0.7 0.7 0.7]);
            xlabel('Method');
            ylabel('Computation Time (s)');
            title(sprintf('Computation Time: %.4f s', solver.computationTime));
            set(gca, 'XTickLabel', {solver.name});
            grid on;
        end
    end
end