classdef SecantSolver < RootFindingSolver
    % SECANTSOLVER Concrete implementation of Secant method
    
    properties
        secondGuess
    end
    
    methods
        function obj = SecantSolver(f, x0, x1, tolerance, maxIterations)
            obj = obj@RootFindingSolver('Secant', f, [], x0, tolerance, maxIterations);
            obj.secondGuess = x1;
        end
        
        function result = solve(obj)
            % Implement Secant method recursively
            tic;
            obj.validateParameters();
            
            [obj.root, obj.iterations, obj.history] = obj.recursiveSecant(...
                obj.initialGuess, obj.secondGuess, 1, []);
            
            obj.functionValue = obj.problemFunction(obj.root);
            obj.computationTime = toc;
            
            result = struct('root', obj.root, 'iterations', obj.iterations, ...
                          'time', obj.computationTime, 'converged', obj.hasConverged);
        end
        
        function [root, iter, history] = recursiveSecant(obj, x0, x1, currentIter, history)
            % Recursive Secant implementation
            if currentIter > obj.maxIterations
                root = x1;
                iter = currentIter - 1;
                fprintf('  Maximum iterations reached: %d\n', obj.maxIterations);
                return;
            end
            
            fx0 = obj.problemFunction(x0);
            fx1 = obj.problemFunction(x1);
            
            if abs(fx1 - fx0) < eps
                error('Division by zero avoided at iteration %d', currentIter);
            end
            
            x2 = x1 - fx1 * (x1 - x0) / (fx1 - fx0);
            history(currentIter) = x2;
            error_val = abs(x2 - x1);
            obj.recordHistory(x2, error_val);
            
            fprintf('  Iteration %d: x = %.8f, f(x) = %.2e, error = %.2e\n', ...
                    currentIter, x2, obj.problemFunction(x2), error_val);
            
            if obj.checkConvergence(error_val, currentIter)
                root = x2;
                iter = currentIter;
                fprintf('  Converged in %d iterations\n', currentIter);
            else
                [root, iter, history] = obj.recursiveSecant(x1, x2, currentIter + 1, history);
            end
        end
        
        function validateParameters(obj)
            % Validate Secant method parameters
            validateParameters@RootFindingSolver(obj);
            
            if isempty(obj.secondGuess)
                error('Second initial guess must be specified for Secant method');
            end
            
            if obj.initialGuess == obj.secondGuess
                error('Initial guesses must be different for Secant method');
            end
            
            fprintf('Secant method parameters validated\n');
        end
    end
end