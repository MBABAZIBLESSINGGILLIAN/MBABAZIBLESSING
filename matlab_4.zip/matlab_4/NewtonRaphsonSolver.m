classdef NewtonRaphsonSolver < RootFindingSolver
    % NEWTONRAPHSONSOLVER Concrete implementation of Newton-Raphson method
    
    methods
        function obj = NewtonRaphsonSolver(f, df, x0, tolerance, maxIterations)
            obj = obj@RootFindingSolver('Newton-Raphson', f, df, x0, tolerance, maxIterations);
        end
        
        function result = solve(obj)
            % Implement Newton-Raphson method recursively
            tic;
            obj.validateParameters();
            
            [obj.root, obj.iterations, obj.history] = obj.recursiveNewton(...
                obj.initialGuess, 1, []);
            
            obj.functionValue = obj.problemFunction(obj.root);
            obj.computationTime = toc;
            
            result = struct('root', obj.root, 'iterations', obj.iterations, ...
                          'time', obj.computationTime, 'converged', obj.hasConverged);
        end
        
        function [root, iter, history] = recursiveNewton(obj, x0, currentIter, history)
            % Recursive Newton-Raphson implementation
            if currentIter > obj.maxIterations
                root = x0;
                iter = currentIter - 1;
                return;
            end
            
            fx = obj.problemFunction(x0);
            dfx = obj.derivativeFunction(x0);
            
            if abs(dfx) < eps
                error('Derivative too small at iteration %d', currentIter);
            end
            
            x1 = x0 - fx/dfx;
            history(currentIter) = x1;
            error_val = abs(x1 - x0);
            obj.recordHistory(x1, error_val);
            
            fprintf('  Iteration %d: x = %.8f, f(x) = %.2e, error = %.2e\n', ...
                    currentIter, x1, obj.problemFunction(x1), error_val);
            
            if obj.checkConvergence(error_val, currentIter)
                root = x1;
                iter = currentIter;
            else
                [root, iter, history] = obj.recursiveNewton(x1, currentIter + 1, history);
            end
        end
    end
end